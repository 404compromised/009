#include <stdio.h>
#include <omp.h>
void main()
{
int arr1[5] = {1, 2, 3, 4, 5};
int arr2[5] = {6, 7, 8, 9, 10};int result[5];
int tid;
#pragma omp parallel num_threads(5)
{
tid = omp_get_thread_num();
result[tid] = arr1[tid] + arr2[tid];
printf("result[%d] = %d\n", tid, result[tid]);
}
}
