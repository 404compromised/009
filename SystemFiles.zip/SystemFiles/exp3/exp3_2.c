#include <stdio.h>
#include <omp.h>
void main()
{
int arr1[10] = {1, 2, 3, 4, 5,6, 7, 8, 9, 10};
int arr2[10] = {6, 7, 8, 9, 10,1, 2, 3, 4, 5};
int result[10];
int tid,i,j;
#pragma omp parallel num_threads(5)
{
tid = omp_get_thread_num();
j=tid*2+2;
for (i=tid*2;i<j;i++)
{
result[i] = arr1[i] + arr2[i];
}
}
for(i=0;i<10;i++)
printf("result[%d] = %d\n", i, result[i]);
}
